
import { KOLProfile, ScrapedPost } from '../types';

const MOCK_KOLS: KOLProfile[] = [
  { id: '1', handle: '@elonmusk', name: 'Elon Musk', avatar: 'https://unavatar.io/twitter/elonmusk', category: 'Tech', verified: true },
  { id: '2', handle: '@ycombinator', name: 'Y Combinator', avatar: 'https://unavatar.io/twitter/ycombinator', category: 'VC', verified: true },
  { id: '3', handle: '@reactjs', name: 'React', avatar: 'https://unavatar.io/twitter/reactjs', category: 'Dev', verified: true },
];

const INITIAL_POSTS: ScrapedPost[] = [
  {
    id: '101',
    kolId: '1',
    kolHandle: '@elonmusk',
    kolName: 'Elon Musk',
    kolAvatar: 'https://unavatar.io/twitter/elonmusk',
    content: "Make humanity multi-planetary! 🚀 Mars awaits.",
    timestamp: Date.now() - 86400000,
    likes: 45200,
    retweets: 12000,
    replies: 5400,
    views: 1500000,
    url: 'https://x.com/elonmusk/status/101',
    isArchived: true
  },
  {
    id: '102',
    kolId: '3',
    kolHandle: '@reactjs',
    kolName: 'React',
    kolAvatar: 'https://unavatar.io/twitter/reactjs',
    content: "React Server Components are now stable. Here is what you need to know about the future of web development.",
    timestamp: Date.now() - 172800000,
    likes: 5000,
    retweets: 1200,
    replies: 300,
    views: 250000,
    url: 'https://x.com/reactjs/status/102',
    isArchived: true
  }
];

// Simulate backend persistence
export const getPosts = (): ScrapedPost[] => {
  const stored = localStorage.getItem('x_insight_posts');
  if (!stored) {
    localStorage.setItem('x_insight_posts', JSON.stringify(INITIAL_POSTS));
    return INITIAL_POSTS;
  }
  return JSON.parse(stored);
};

export const savePost = (post: ScrapedPost) => {
  const current = getPosts();
  // Check for duplicates
  if (current.some(p => p.id === post.id)) return current;
  
  const updated = [post, ...current];
  localStorage.setItem('x_insight_posts', JSON.stringify(updated));
  return updated;
};

export const getKOLs = () => MOCK_KOLS;
