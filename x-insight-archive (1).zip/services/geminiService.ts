import { GoogleGenAI, Type, Schema } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

const analysisSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    sentiment: {
      type: Type.STRING,
      enum: ['Positive', 'Neutral', 'Negative'],
      description: "The overall sentiment of the post."
    },
    summary: {
      type: Type.STRING,
      description: "A concise one-sentence summary of the post."
    },
    keyTopics: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Up to 3 key topics mentioned in the post."
    }
  },
  required: ['sentiment', 'summary', 'keyTopics']
};

export const analyzePostContent = async (text: string) => {
  if (!apiKey) {
    console.warn("No API Key provided. Returning mock analysis.");
    return {
      sentiment: 'Neutral' as const,
      summary: 'API Key missing. Simulating analysis.',
      keyTopics: ['Demo', 'No API']
    };
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Analyze the following social media post text for a marketing insights dashboard: "${text}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
        systemInstruction: "You are an expert social media analyst. Be concise and professional.",
      }
    });

    const jsonText = response.text;
    if (!jsonText) throw new Error("Empty response from Gemini");
    return JSON.parse(jsonText);
  } catch (error) {
    console.error("Gemini analysis failed:", error);
    // Fallback for error states
    return {
      sentiment: 'Neutral' as const,
      summary: 'Analysis failed due to error.',
      keyTopics: ['Error']
    };
  }
};