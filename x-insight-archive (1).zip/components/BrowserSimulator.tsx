
import React, { useState, useRef, useEffect } from 'react';
import { KOLProfile, ScrapedPost } from '../types';
import { Search, ArrowRight, RefreshCw, Home, Bell, Mail, User, MoreHorizontal, Image as ImageIcon, Smile, Calendar, MapPin, Heart, Repeat, MessageCircle, BarChart2, Save, CheckCircle, Download } from 'lucide-react';
import { savePost } from '../services/mockData';

interface BrowserSimulatorProps {
  onCapture: () => void;
  kols: KOLProfile[];
}

export const BrowserSimulator: React.FC<BrowserSimulatorProps> = ({ onCapture, kols }) => {
  const [url, setUrl] = useState('https://x.com/home');
  const [isLoading, setIsLoading] = useState(false);
  const [showContent, setShowContent] = useState(true);
  const [activePostId, setActivePostId] = useState<string | null>(null);

  // Mock "Live" Feed
  const [feed, setFeed] = useState<ScrapedPost[]>([]);

  useEffect(() => {
    // Generate some mock feed data based on KOLs
    const generatedFeed = kols.flatMap(kol => [
      {
        id: `live-${kol.id}-1`,
        kolId: kol.id,
        kolHandle: kol.handle,
        kolName: kol.name,
        kolAvatar: kol.avatar,
        content: `Just deployed the backend for the scraping engine using Python & Playwright. It works seamlessly with the Vue dashboard! #coding #python`,
        timestamp: Date.now() - Math.floor(Math.random() * 3600000),
        likes: 120 + Math.floor(Math.random() * 500),
        retweets: 20 + Math.floor(Math.random() * 100),
        replies: 10,
        views: 5000,
        url: `https://x.com/${kol.handle.replace('@', '')}/status/${Date.now()}`,
        isArchived: false
      },
      {
        id: `live-${kol.id}-2`,
        kolId: kol.id,
        kolHandle: kol.handle,
        kolName: kol.name,
        kolAvatar: kol.avatar,
        content: `Market analysis for today: Trend is upward. Saving this chart to my dashboard. 📈`,
        timestamp: Date.now() - Math.floor(Math.random() * 86400000),
        likes: 890,
        retweets: 150,
        replies: 45,
        views: 22000,
        url: `https://x.com/${kol.handle.replace('@', '')}/status/${Date.now()-1000}`,
        isArchived: false
      }
    ]).sort((a, b) => b.timestamp - a.timestamp);
    setFeed(generatedFeed);
  }, [kols]);

  const handleNavigate = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      if (url.includes('x.com') || url.includes('twitter.com')) {
        setShowContent(true);
      } else {
        setShowContent(false);
      }
    }, 800);
  };

  const handleSavePost = (post: ScrapedPost) => {
    setActivePostId(post.id);
    // Simulate backend delay
    setTimeout(() => {
      const postToSave = { ...post, isArchived: true, timestamp: Date.now() };
      savePost(postToSave);
      
      // Update local feed state to show it's saved
      setFeed(current => current.map(p => p.id === post.id ? { ...p, isArchived: true } : p));
      
      setActivePostId(null);
      onCapture();
    }, 600);
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-lg overflow-hidden shadow-2xl border border-slate-700/30">
      {/* Browser Toolbar */}
      <div className="bg-[#202124] border-b border-[#3c4043] p-2 flex items-center gap-3">
        <div className="flex gap-1.5 opacity-50">
          <div className="w-3 h-3 rounded-full bg-red-400"></div>
          <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
          <div className="w-3 h-3 rounded-full bg-green-400"></div>
        </div>
        <div className="flex items-center gap-2 text-slate-400">
          <RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} />
        </div>
        <form onSubmit={handleNavigate} className="flex-1">
          <div className="w-full bg-[#171717] border border-[#5f6368] rounded-full px-4 py-1.5 text-sm text-slate-300 flex items-center gap-2 focus-within:border-blue-500 transition-colors">
            <Search size={14} className="text-slate-500" />
            <input 
              type="text" 
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="flex-1 bg-transparent outline-none placeholder-slate-600"
              placeholder="Enter URL"
            />
          </div>
        </form>
      </div>

      {/* Browser Content Area */}
      <div className="flex-1 bg-black overflow-y-auto relative scroll-smooth">
        {isLoading && (
          <div className="absolute inset-0 bg-black z-50 flex items-center justify-center">
             <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          </div>
        )}

        {!showContent ? (
          <div className="h-full flex flex-col items-center justify-center text-slate-500 gap-4">
            <div className="w-16 h-16 rounded-full bg-slate-900 flex items-center justify-center">
              <Search size={32} />
            </div>
            <p>Navigate to <strong>x.com</strong> to start the scraper.</p>
            <button 
              onClick={() => { setUrl('https://x.com/home'); handleNavigate({ preventDefault: () => {} } as any); }}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-full text-sm transition-colors"
            >
              Go to X.com
            </button>
          </div>
        ) : (
          /* MOCK X UI */
          <div className="min-h-full flex text-slate-200 font-sans">
            
            {/* Left Sidebar (Mock) */}
            <div className="w-[80px] md:w-[250px] border-r border-slate-800 p-4 flex flex-col justify-between hidden sm:flex sticky top-0 h-screen">
               <div className="space-y-6">
                  <div className="pl-2">
                    <svg viewBox="0 0 24 24" className="w-8 h-8 text-white fill-current"><g><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"></path></g></svg>
                  </div>
                  <nav className="space-y-4 text-xl font-medium">
                    <div className="flex items-center gap-4 p-2 hover:bg-slate-900 rounded-full cursor-pointer font-bold">
                      <Home size={26} /> <span className="hidden md:inline">Home</span>
                    </div>
                    <div className="flex items-center gap-4 p-2 hover:bg-slate-900 rounded-full cursor-pointer">
                      <Search size={26} /> <span className="hidden md:inline">Explore</span>
                    </div>
                    <div className="flex items-center gap-4 p-2 hover:bg-slate-900 rounded-full cursor-pointer">
                      <Bell size={26} /> <span className="hidden md:inline">Notifications</span>
                    </div>
                    <div className="flex items-center gap-4 p-2 hover:bg-slate-900 rounded-full cursor-pointer">
                      <Mail size={26} /> <span className="hidden md:inline">Messages</span>
                    </div>
                    <div className="flex items-center gap-4 p-2 hover:bg-slate-900 rounded-full cursor-pointer">
                      <User size={26} /> <span className="hidden md:inline">Profile</span>
                    </div>
                  </nav>
               </div>
            </div>

            {/* Main Feed (Mock) */}
            <div className="flex-1 max-w-[600px] border-r border-slate-800">
              {/* Header */}
              <div className="h-14 border-b border-slate-800 bg-black/80 backdrop-blur-md sticky top-0 z-10 flex items-center px-4">
                 <h2 className="font-bold text-lg">For you</h2>
              </div>

              {/* Compose Box Mock */}
              <div className="p-4 border-b border-slate-800 flex gap-4">
                 <div className="w-10 h-10 rounded-full bg-slate-700 flex-shrink-0"></div>
                 <div className="flex-1">
                    <div className="h-10 flex items-center text-slate-500 text-lg">What is happening?!</div>
                    <div className="flex justify-between items-center mt-2 text-blue-400">
                       <div className="flex gap-2">
                          <ImageIcon size={18} />
                          <Smile size={18} />
                          <Calendar size={18} />
                          <MapPin size={18} />
                       </div>
                       <div className="px-4 py-1.5 bg-blue-500 text-white font-bold rounded-full text-sm opacity-50">Post</div>
                    </div>
                 </div>
              </div>

              {/* Feed Items */}
              <div className="pb-20">
                {feed.map(post => (
                  <div key={post.id} className="p-4 border-b border-slate-800 hover:bg-slate-900/30 transition-colors relative group">
                     {/* Save Button Overlay */}
                     <div className="absolute top-4 right-4 z-20">
                        <button 
                          onClick={() => handleSavePost(post)}
                          disabled={post.isArchived || activePostId === post.id}
                          className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold shadow-lg transition-all ${
                            post.isArchived 
                              ? 'bg-green-500/20 text-green-400 border border-green-500/50' 
                              : 'bg-white text-black hover:bg-slate-200'
                          }`}
                        >
                          {activePostId === post.id ? (
                            <RefreshCw size={14} className="animate-spin" />
                          ) : post.isArchived ? (
                            <>
                              <CheckCircle size={14} />
                              <span>Archived</span>
                            </>
                          ) : (
                            <>
                              <Download size={14} />
                              <span>Save to DB</span>
                            </>
                          )}
                        </button>
                     </div>

                     <div className="flex gap-3">
                       <img src={post.kolAvatar} alt="avatar" className="w-10 h-10 rounded-full bg-slate-700" />
                       <div className="flex-1">
                          <div className="flex items-center gap-1 text-sm">
                             <span className="font-bold text-white">{post.kolName}</span>
                             <span className="text-slate-500">{post.kolHandle} · 2h</span>
                          </div>
                          <p className="text-slate-200 mt-1 mb-2 whitespace-pre-wrap">{post.content}</p>
                          
                          <div className="flex justify-between text-slate-500 text-sm max-w-md mt-2">
                             <div className="flex items-center gap-1"><MessageCircle size={16} /> <span>{post.replies}</span></div>
                             <div className="flex items-center gap-1"><Repeat size={16} /> <span>{post.retweets}</span></div>
                             <div className="flex items-center gap-1"><Heart size={16} /> <span>{post.likes}</span></div>
                             <div className="flex items-center gap-1"><BarChart2 size={16} /> <span>{post.views}</span></div>
                          </div>
                       </div>
                     </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right Sidebar (Mock) */}
            <div className="w-[350px] pl-8 py-4 hidden lg:block">
               <div className="bg-[#202327] rounded-full py-2 px-4 flex items-center gap-3 text-slate-500 mb-6">
                  <Search size={18} />
                  <span>Search</span>
               </div>

               <div className="bg-[#16181c] rounded-xl p-4 space-y-4">
                  <h3 className="font-bold text-xl">Trends for you</h3>
                  <div className="space-y-1">
                     <div className="text-xs text-slate-500">Technology · Trending</div>
                     <div className="font-bold">Python</div>
                     <div className="text-xs text-slate-500">125K posts</div>
                  </div>
                  <div className="space-y-1">
                     <div className="text-xs text-slate-500">Business · Trending</div>
                     <div className="font-bold">Startups</div>
                     <div className="text-xs text-slate-500">54K posts</div>
                  </div>
               </div>
            </div>

          </div>
        )}
      </div>
    </div>
  );
};
