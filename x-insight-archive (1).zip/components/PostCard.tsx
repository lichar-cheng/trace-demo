
import React from 'react';
import { ScrapedPost } from '../types';
import { Heart, Repeat, MessageCircle, BarChart2, Share } from 'lucide-react';

interface PostCardProps {
  post: ScrapedPost;
}

export const PostCard: React.FC<PostCardProps> = ({ post }) => {
  const formatDate = (ts: number) => new Date(ts).toLocaleDateString();

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  return (
    <div className="bg-black/20 border border-slate-800 rounded-xl p-4 mb-4 hover:bg-slate-900/30 transition-colors">
      <div className="flex gap-3">
        {/* Avatar */}
        <div className="flex-shrink-0">
          <img 
            src={post.kolAvatar || 'https://abs.twimg.com/sticky/default_profile_images/default_profile_normal.png'} 
            alt={post.kolHandle} 
            className="w-10 h-10 rounded-full"
          />
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 text-sm mb-0.5">
            <span className="font-bold text-slate-200 truncate">{post.kolName}</span>
            {/* Verified Badge Mock */}
            <svg viewBox="0 0 22 22" className="w-4 h-4 text-blue-400 fill-current" aria-label="Verified account">
              <g><path d="M20.396 11c-.018-.646-.215-1.275-.57-1.816-.354-.54-.852-.972-1.438-1.246.223-.607.27-1.264.14-1.897-.131-.634-.437-1.218-.882-1.687-.47-.445-1.053-.75-1.687-.882-.633-.13-1.29-.083-1.897.14-.273-.587-.704-1.086-1.245-1.44S11.647 1.62 11 1.604c-.646.017-1.273.213-1.813.568s-.969.854-1.24 1.44c-.608-.223-1.267-.272-1.902-.14-.635.13-1.22.436-1.687.882-.445.47-.749 1.055-.878 1.688-.13.633-.08 1.29.144 1.896-.587.274-1.087.705-1.443 1.245-.356.54-.555 1.17-.574 1.817.02.647.218 1.276.574 1.817.356.54.856.972 1.443 1.245-.224.606-.274 1.263-.144 1.896.13.634.433 1.218.877 1.688.47.443 1.054.747 1.687.882.635.132 1.294.084 1.902-.14.271.585.696 1.084 1.24 1.439.54.354 1.166.551 1.813.568.647-.016 1.274-.213 1.813-.567.54-.355.971-.854 1.245-1.44.604.224 1.26.27 1.897.14.634-.13 1.217-.436 1.687-.882.445-.469.751-1.054.882-1.687.13-.633.083-1.29-.14-1.897.585-.273 1.084-.704 1.438-1.246.355-.54.552-1.17.57-1.816zM9.662 14.85l-3.429-3.428 1.293-1.293 2.136 2.137 5.422-5.422 1.293 1.293-6.715 6.715z"></path></g>
            </svg>
            <span className="text-slate-500 truncate">{post.kolHandle}</span>
            <span className="text-slate-600">·</span>
            <span className="text-slate-500 hover:underline cursor-pointer">{formatDate(post.timestamp)}</span>
          </div>

          <p className="text-slate-300 whitespace-pre-wrap text-[15px] leading-normal mb-3">
            {post.content}
          </p>

          {post.mediaUrl && (
            <div className="mt-3 mb-3 rounded-xl overflow-hidden border border-slate-800">
               <img src={post.mediaUrl} alt="Post media" className="w-full h-auto object-cover" />
            </div>
          )}

          <div className="flex justify-between max-w-md text-slate-500 text-sm mt-2">
            <div className="flex items-center gap-2 group cursor-pointer hover:text-blue-400">
              <div className="p-1.5 rounded-full group-hover:bg-blue-500/10 transition-colors">
                <MessageCircle size={18} />
              </div>
              <span>{formatNumber(post.replies || 0)}</span>
            </div>
            <div className="flex items-center gap-2 group cursor-pointer hover:text-green-400">
              <div className="p-1.5 rounded-full group-hover:bg-green-500/10 transition-colors">
                <Repeat size={18} />
              </div>
              <span>{formatNumber(post.retweets)}</span>
            </div>
            <div className="flex items-center gap-2 group cursor-pointer hover:text-pink-400">
              <div className="p-1.5 rounded-full group-hover:bg-pink-500/10 transition-colors">
                <Heart size={18} />
              </div>
              <span>{formatNumber(post.likes)}</span>
            </div>
            <div className="flex items-center gap-2 group cursor-pointer hover:text-blue-400">
              <div className="p-1.5 rounded-full group-hover:bg-blue-500/10 transition-colors">
                <BarChart2 size={18} />
              </div>
              <span>{formatNumber(post.views || 0)}</span>
            </div>
            <div className="flex items-center gap-2 group cursor-pointer hover:text-blue-400">
              <div className="p-1.5 rounded-full group-hover:bg-blue-500/10 transition-colors">
                 <Share size={18} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
