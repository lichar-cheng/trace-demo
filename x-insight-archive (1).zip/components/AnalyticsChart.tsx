import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { ScrapedPost } from '../types';

interface AnalyticsChartProps {
  posts: ScrapedPost[];
}

export const AnalyticsChart: React.FC<AnalyticsChartProps> = ({ posts }) => {
  // Process data: Count posts by KOL
  const dataMap = posts.reduce((acc, post) => {
    acc[post.kolId] = (acc[post.kolId] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const data = Object.keys(dataMap).map(kolId => ({
    name: `KOL ${kolId}`, // In real app, map ID to Name
    value: dataMap[kolId]
  }));

  const COLORS = ['#3b82f6', '#06b6d4', '#8b5cf6', '#ec4899'];

  if (posts.length === 0) {
    return (
      <div className="h-full flex items-center justify-center text-secondary">
        No data available for visualization.
      </div>
    );
  }

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <XAxis 
            dataKey="name" 
            stroke="#64748b" 
            fontSize={12} 
            tickLine={false} 
            axisLine={false} 
          />
          <YAxis 
            stroke="#64748b" 
            fontSize={12} 
            tickLine={false} 
            axisLine={false} 
          />
          <Tooltip 
            cursor={{fill: 'transparent'}}
            contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#f1f5f9' }}
            itemStyle={{ color: '#f1f5f9' }}
          />
          <Bar dataKey="value" radius={[4, 4, 0, 0]}>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};