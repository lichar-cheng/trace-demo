
import React, { useState, useEffect } from 'react';
import { LayoutDashboard, Globe, Archive, Menu, X, Database, Code, Terminal } from 'lucide-react';
import { ViewMode, KOLProfile, ScrapedPost } from './types';
import { BrowserSimulator } from './components/BrowserSimulator';
import { PostCard } from './components/PostCard';
import { AnalyticsChart } from './components/AnalyticsChart';
import { getKOLs, getPosts } from './services/mockData';

// Helper component to display code
const CodeBlock = ({ title, code, lang = 'python' }: { title: string, code: string, lang?: string }) => (
  <div className="bg-[#1e1e1e] rounded-lg overflow-hidden border border-slate-700 mb-6 shadow-lg">
    <div className="bg-[#252526] px-4 py-2 border-b border-slate-700 flex justify-between items-center">
      <span className="text-sm font-mono text-slate-300">{title}</span>
      <div className="flex gap-1.5">
        <div className="w-3 h-3 rounded-full bg-red-500/20"></div>
        <div className="w-3 h-3 rounded-full bg-yellow-500/20"></div>
        <div className="w-3 h-3 rounded-full bg-green-500/20"></div>
      </div>
    </div>
    <div className="p-4 overflow-x-auto">
      <pre className="font-mono text-sm text-slate-300 whitespace-pre">{code}</pre>
    </div>
  </div>
);

const App: React.FC = () => {
  const [view, setView] = useState<ViewMode>(ViewMode.BROWSER);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  
  const [posts, setPosts] = useState<ScrapedPost[]>(() => getPosts());
  const [kols, setKols] = useState<KOLProfile[]>(() => getKOLs());
  
  const refreshPosts = () => {
    setPosts(getPosts());
  };

  const navItems = [
    { id: ViewMode.BROWSER, label: 'Browser & Capture', icon: Globe },
    { id: ViewMode.DASHBOARD, label: 'Analytics', icon: LayoutDashboard },
    { id: ViewMode.ARCHIVE, label: 'Archive', icon: Archive },
    { id: ViewMode.BACKEND_CODE, label: 'Backend Setup', icon: Terminal },
  ];

  // Load file contents for display (In a real app these would be fetched)
  const backendCode = `
# backend/server.py

from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3

app = Flask(__name__)
CORS(app)

@app.route('/api/posts', methods=['POST'])
def save_post():
    data = request.json
    # Save to SQLite logic...
    return jsonify({"status": "saved"}), 201

if __name__ == '__main__':
    app.run(port=5000)
  `.trim();

  const scraperCode = `
# backend/scraper.py
import asyncio
from playwright.async_api import async_playwright

async def run():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        page = await browser.new_page()
        await page.goto("https://x.com")
        # Scraping logic...
        
if __name__ == "__main__":
    asyncio.run(run())
  `.trim();

  return (
    <div className="flex h-screen bg-background text-slate-200 font-sans selection:bg-blue-500/30">
      
      {/* Sidebar */}
      <div 
        className={`${isSidebarOpen ? 'w-64' : 'w-20'} 
        bg-surface border-r border-slate-700/50 flex flex-col transition-all duration-300 z-20 relative`}
      >
        <div className="h-16 flex items-center justify-center border-b border-slate-700/50">
           {isSidebarOpen ? (
             <div className="flex items-center gap-2 text-white font-bold text-xl tracking-tight">
               <Database className="text-blue-500" />
               <span>X-Archiver</span>
             </div>
           ) : (
             <Database className="text-blue-500" />
           )}
        </div>

        <nav className="flex-1 py-6 px-3 space-y-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setView(item.id)}
              className={`w-full flex items-center ${isSidebarOpen ? 'justify-start px-4' : 'justify-center px-0'} 
              py-3 rounded-xl transition-all duration-200 group
              ${view === item.id ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/25' : 'text-secondary hover:bg-slate-700/50 hover:text-slate-100'}`}
            >
              <item.icon size={20} />
              {isSidebarOpen && <span className="ml-3 font-medium">{item.label}</span>}
            </button>
          ))}
        </nav>

        <button 
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="absolute -right-3 top-20 bg-surface border border-slate-600 text-secondary rounded-full p-1 hover:text-white transition-colors"
        >
          {isSidebarOpen ? <X size={14} /> : <Menu size={14} />}
        </button>
      </div>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full overflow-hidden relative bg-background">
        <div className="flex-1 overflow-hidden p-6">
          
          {/* VIEW: BROWSER */}
          {view === ViewMode.BROWSER && (
            <div className="flex h-full gap-6">
              <div className="flex-1 h-full min-w-0">
                <BrowserSimulator onCapture={refreshPosts} kols={kols} />
              </div>
              <div className="w-80 bg-surface rounded-lg border border-slate-700/50 flex flex-col overflow-hidden hidden xl:flex">
                <div className="p-4 border-b border-slate-700/50 flex justify-between items-center">
                  <h3 className="font-semibold text-slate-200">Live Database</h3>
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                </div>
                <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
                  {posts.slice(0, 10).map(post => (
                     <PostCard key={post.id} post={post} />
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* VIEW: DASHBOARD */}
          {view === ViewMode.DASHBOARD && (
            <div className="grid grid-cols-12 gap-6 h-full overflow-y-auto">
              <div className="col-span-12 lg:col-span-4 bg-surface rounded-xl p-6 border border-slate-700/50 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-6 text-slate-700"><Archive size={64} opacity={0.2} /></div>
                <p className="text-secondary text-sm mb-1">Total Archived Posts</p>
                <h3 className="text-4xl font-bold text-white">{posts.length}</h3>
              </div>
              <div className="col-span-12 lg:col-span-4 bg-surface rounded-xl p-6 border border-slate-700/50 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-6 text-slate-700"><Globe size={64} opacity={0.2} /></div>
                <p className="text-secondary text-sm mb-1">Monitored Accounts</p>
                <h3 className="text-4xl font-bold text-white">{kols.length}</h3>
              </div>
              <div className="col-span-12 lg:col-span-4 bg-surface rounded-xl p-6 border border-slate-700/50 relative overflow-hidden">
                 <div className="absolute top-0 right-0 p-6 text-slate-700"><Code size={64} opacity={0.2} /></div>
                 <p className="text-secondary text-sm mb-1">Backend Status</p>
                 <h3 className="text-4xl font-bold text-green-400">Active</h3>
              </div>

              <div className="col-span-12 bg-surface rounded-xl p-6 border border-slate-700/50 min-h-[300px]">
                <h3 className="text-lg font-semibold text-slate-200 mb-6">Post Volume by Source</h3>
                <AnalyticsChart posts={posts} />
              </div>
            </div>
          )}

          {/* VIEW: ARCHIVE */}
          {view === ViewMode.ARCHIVE && (
            <div className="h-full overflow-hidden flex flex-col bg-surface rounded-xl border border-slate-700/50">
               <div className="p-4 border-b border-slate-700/50">
                 <h3 className="font-semibold text-slate-200">Full Database Records</h3>
               </div>
               <div className="flex-1 overflow-y-auto p-6">
                 <div className="max-w-3xl mx-auto space-y-4">
                    {posts.map(post => (
                      <PostCard key={post.id} post={post} />
                    ))}
                 </div>
               </div>
            </div>
          )}

          {/* VIEW: BACKEND CODE */}
          {view === ViewMode.BACKEND_CODE && (
            <div className="h-full overflow-y-auto">
              <div className="max-w-4xl mx-auto">
                <div className="mb-8">
                  <h2 className="text-2xl font-bold text-white mb-2">Backend Integration</h2>
                  <p className="text-slate-400">
                    To run this system locally, use the following Python code. 
                    This includes a Flask API server and a Playwright scraper script.
                  </p>
                </div>

                <h3 className="text-lg font-semibold text-blue-400 mb-4">1. API Server (Flask + SQLite)</h3>
                <CodeBlock title="backend/server.py" code={backendCode} />

                <h3 className="text-lg font-semibold text-blue-400 mb-4">2. Browser Scraper (Playwright)</h3>
                <CodeBlock title="backend/scraper.py" code={scraperCode} />
              </div>
            </div>
          )}

        </div>
      </main>
    </div>
  );
};

export default App;
