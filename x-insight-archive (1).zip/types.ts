
export interface KOLProfile {
  id: string;
  handle: string;
  name: string;
  avatar: string;
  category: string;
  verified?: boolean;
}

export interface ScrapedPost {
  id: string;
  kolId: string;
  kolHandle?: string;
  kolName?: string;
  kolAvatar?: string;
  content: string;
  timestamp: number;
  likes: number;
  retweets: number;
  replies?: number;
  views?: number;
  url: string;
  mediaUrl?: string;
  isArchived?: boolean;
}

export enum ViewMode {
  BROWSER = 'BROWSER',
  DASHBOARD = 'DASHBOARD',
  ARCHIVE = 'ARCHIVE',
  BACKEND_CODE = 'BACKEND_CODE',
}

export interface ChartData {
  name: string;
  value: number;
}
